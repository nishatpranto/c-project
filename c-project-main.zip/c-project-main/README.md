# c-project
Smart - Inventory- system- project
